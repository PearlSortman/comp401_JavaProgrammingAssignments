package otherTokens;

public interface NumberTokenInterface {

	public int getNumberValue();
	
}
