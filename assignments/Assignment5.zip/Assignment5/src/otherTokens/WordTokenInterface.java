package otherTokens;

public interface WordTokenInterface {
	
	public String getLowerCaseWord();

}
