package linesAndShapes;

public interface VShapeInterface {

}
