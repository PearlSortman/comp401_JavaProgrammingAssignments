package commands;

public interface TokenInterface {
	
	public String getOriginalString();
	public void setOriginalString(String originalString);

}
