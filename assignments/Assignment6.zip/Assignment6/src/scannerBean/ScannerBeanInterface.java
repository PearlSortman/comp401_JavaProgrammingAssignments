package scannerBean;
public interface ScannerBeanInterface {

	public void scan();
	
}
