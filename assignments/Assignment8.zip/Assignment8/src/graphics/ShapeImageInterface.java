package graphics;

public interface ShapeImageInterface {
	
	 public String getImageFileName(); 
	 public void setImageFileName(String newVal);

}
