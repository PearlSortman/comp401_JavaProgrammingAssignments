package commands;

public interface NumberTokenInterface extends TokenInterface {

	public int getNumberValue();
	
}
