package main;

public interface WordTokenInterface {
	
	public String getLowerCaseWord();

}
