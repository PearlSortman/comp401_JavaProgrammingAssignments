package main;

public class Minus implements TokenInterface {
	
	private String originalString;
	
	public Minus (String originalString) {
		this.originalString = originalString;
	}

	public String getOriginalString() {
		return originalString;
	}

	public void setOriginalString(String originalString) {
		this.originalString = originalString;
	}

}
