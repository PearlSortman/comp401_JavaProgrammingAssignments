package main;

public class ScannerBean implements TokenInterface, ScannerBeanInterface {
	
	String originalString;
	
	public ScannerBean(String originalString) {
		this.originalString = originalString;
	}
	
	public String getOriginalString() {
		return originalString;
	}

	public void setOriginalString(String originalString) {
		this.originalString = originalString;
	}

	public void scan() {
		
		int startIndex = 0;
		int stopIndex = 0;

		String mySubstring = "";

		boolean isQuote = false;

		while (++stopIndex < originalString.length()) {

			if (startIndex >= originalString.length()) {
				break;
			}

			if (originalString.charAt(startIndex) == '"' || isQuote) {

				isQuote = true;

				if (stopIndex + 1 < originalString.length() && originalString.charAt(stopIndex + 1) == '"') {
					mySubstring = originalString.substring(startIndex + 1, stopIndex + 1);
					System.out.println("quoted string: " + mySubstring);
					isQuote = false;
					startIndex = stopIndex + 2;
				}
			} 
			
			else if (Character.isDigit(originalString.charAt(startIndex))) {

				if (!Character.isDigit(originalString.charAt(stopIndex))) {
					mySubstring = originalString.substring(startIndex, stopIndex);
					startIndex = stopIndex + 1;
					Number number = new Number(mySubstring);
					System.out.println(number.toString());
					System.out.println(number.getOriginalString());
					System.out.println(number.getNumberValue());
				}
			} 
			
			else if (Character.isLetter(originalString.charAt(startIndex))) {

				if (!Character.isLetter(originalString.charAt(stopIndex)) || originalString.charAt(stopIndex) == '}') {
					mySubstring = originalString.substring(startIndex, stopIndex);
					startIndex = stopIndex + 1;
					Word word = new Word(mySubstring);
					System.out.println(word.toString());
					System.out.println(word.getOrignalString());
					System.out.println(word.getLowerCaseWord());
				}
			} 
			
			else if (originalString.charAt(startIndex) == '{') {
				
				if (originalString.charAt(stopIndex) != '{') {
					mySubstring = originalString.substring(startIndex, stopIndex);
					startIndex = stopIndex + 1;
					StartToken startToken = new StartToken(mySubstring);
					System.out.println(startToken.toString());
					System.out.println(startToken.getOriginalString());
				}
			}
			
			else if (originalString.charAt(startIndex) == '}') {
				
				if (originalString.charAt(stopIndex) != '}') {
					mySubstring = originalString.substring(startIndex, stopIndex);
					startIndex = stopIndex + 1;
					EndToken endToken = new EndToken(mySubstring);
					System.out.println(endToken.toString());
					System.out.println(endToken.getOriginalString());
				}
			}
			
			else if (originalString.charAt(startIndex) == '+') {
				
				if (originalString.charAt(stopIndex) != '+') {
					mySubstring = originalString.substring(startIndex, stopIndex);
					startIndex = stopIndex + 1;
					Plus plus = new Plus(mySubstring);
					System.out.println(plus.toString());
					System.out.println(plus.getOriginalString());	
				}
			}
			
			else if (originalString.charAt(startIndex) == '-') {
				
				if (originalString.charAt(stopIndex) != '-') {
					mySubstring = originalString.substring(startIndex, stopIndex);
					startIndex = stopIndex + 1;
					Minus minus = new Minus(mySubstring);
					System.out.println(minus.toString());
					System.out.println(minus.getOriginalString());
				}
			}
			
			else if (originalString.charAt(stopIndex) == ' ') {
				startIndex++;
			}
		}

	}
}
