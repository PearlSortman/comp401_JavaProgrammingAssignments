package main;

public class Word implements TokenInterface, WordTokenInterface {
	
	private String orignalString;
	
	private String lowerCaseWord;
	
	public Word(String orignalString) {
		
		this.orignalString = orignalString;
		lowerCaseWord = orignalString.toLowerCase();
	}

	public String getOrignalString() {
		return orignalString;
	}

	public void setOrignalString(String orignalString) {
		this.orignalString = orignalString;
	}

	public String getLowerCaseWord() {
		return lowerCaseWord;
	}

	@Override
	public String getOriginalString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setOriginalString(String originalString) {
		// TODO Auto-generated method stub
		
	}

}
