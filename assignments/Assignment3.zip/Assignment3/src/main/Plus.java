package main;

public class Plus implements TokenInterface {
	
	private String originalString;
	
	public Plus (String originalString) {
		this.originalString = originalString;
	}

	public String getOriginalString() {
		return originalString;
	}

	public void setOriginalString(String originalString) {
		this.originalString = originalString;
	}

}
