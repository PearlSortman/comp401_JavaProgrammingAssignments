package main;

public interface NumberTokenInterface {

	public int getNumberValue();
	
}
