package main;

public class QuotedString implements TokenInterface {
	
	private String originalString;
	
	public QuotedString(String originalString) {
		this.originalString = originalString;
	}

	public String getOriginalString() {
		return originalString;
	}

	public void setOriginalString(String originalString) {
		this.originalString = originalString;
	}

}
