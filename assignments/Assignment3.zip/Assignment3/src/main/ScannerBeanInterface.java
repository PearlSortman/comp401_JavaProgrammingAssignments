package main;
public interface ScannerBeanInterface {

	public void scan();
	
}
