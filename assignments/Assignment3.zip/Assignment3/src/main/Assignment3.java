package main;
import java.util.Scanner;

public class Assignment3 {
	
	public static void main (String[] args) {
		
		try {
			new Assignment3().run();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void run() throws Exception {

		Scanner myKeyboard = new Scanner(System.in);
		String myInputString = myKeyboard.nextLine();
		

		while (!myInputString.startsWith(".")) {

			ScannerBean scannerBean = new ScannerBean(myInputString);
			scannerBean.scan();
			
			myInputString = myKeyboard.nextLine();
		}
		
		myKeyboard.close();
	}

}
