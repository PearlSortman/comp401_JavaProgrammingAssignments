package controllers;

import java.awt.event.MouseListener;

public interface MouseControllerInterface extends MouseListener {

}
