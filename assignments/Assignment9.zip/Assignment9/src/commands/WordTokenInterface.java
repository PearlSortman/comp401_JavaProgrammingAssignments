package commands;

public interface WordTokenInterface {
	
	public String getLowerCaseWord();

}
