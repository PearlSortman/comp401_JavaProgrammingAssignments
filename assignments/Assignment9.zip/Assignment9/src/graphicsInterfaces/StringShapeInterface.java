package graphicsInterfaces;

public interface StringShapeInterface {
	
	public String getText();
	public void setText(String newText);

}
