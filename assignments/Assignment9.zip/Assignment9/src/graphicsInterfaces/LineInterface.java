package graphicsInterfaces;

public interface LineInterface {
	
	public double getAngle();
	public void setAngle(int i);
	
	public double getRadius();

}
